from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image as KivyImage
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner

class MedApp(App):
    def build(self):
        self.meds_images = {
            "Metoprolol CR": "metoprolol_cr.jpeg",
            "Atorvastatin Calcium": "atorvastatin_calcium.jpeg",
            "Terazosin HCl": "terazosin_hcl.jpeg",
            "Losartan Potassium": "losartan_potassium.jpeg",
            "Amlodipine Besylate": "amlodipine_besylate.jpeg",
            "Methyldopa": "methyldopa.jpeg"
        }
        self.morning_meds = ["Metoprolol CR", "Methyldopa"]
        self.afternoon_meds = ["Methyldopa"]
        self.evening_meds = ["Atorvastatin Calcium", "Terazosin HCl", "Losartan Potassium", "Methyldopa"]

        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

        layout.add_widget(Label(text="請選擇時間："))
        self.time_spinner = Spinner(
            text='請選擇',
            values=('早上', '下午', '晚上'),
            size_hint=(1, None),
            height=44
        )
        layout.add_widget(self.time_spinner)

        layout.add_widget(Label(text="請輸入上壓："))
        self.bp_input = TextInput(multiline=False, input_filter='float')
        layout.add_widget(self.bp_input)

        self.result_label = Label(text="")
        layout.add_widget(self.result_label)

        btn = Button(text="顯示藥物", size_hint=(1, None), height=44)
        btn.bind(on_press=self.show_meds)
        layout.add_widget(btn)

        return layout

    def show_meds(self, instance):
        time_map = {'早上': '1', '下午': '2', '晚上': '3'}
        time = time_map.get(self.time_spinner.text)
        try:
            systolic_pressure = float(self.bp_input.text)
        except:
            self.result_label.text = "請輸入正確的數字"
            return

        if time == "1":
            meds = self.morning_meds.copy()
        elif time == "2":
            meds = self.afternoon_meds.copy()
        elif time == "3":
            meds = self.evening_meds.copy()
        else:
            self.result_label.text = "請選擇時間"
            return

        if systolic_pressure > 120:
            meds.append("Amlodipine Besylate")
        elif systolic_pressure < 100:
            if "Methyldopa" in meds:
                meds.remove("Methyldopa")

        if meds:
            self.result_label.text = "請服用：\n" + "\n".join(meds)
            # Show images in a popup
            content = BoxLayout(orientation='vertical', spacing=5)
            for med in meds:
                img_path = self.meds_images.get(med)
                if img_path:
                    content.add_widget(KivyImage(source=img_path, size_hint=(1, None), height=100))
                content.add_widget(Label(text=med, size_hint=(1, None), height=30))
            popup = Popup(title='藥物圖片', content=content, size_hint=(0.9, 0.9))
            popup.open()
        else:
            self.result_label.text = "此時段無需服藥"

if __name__ == '__main__':
    MedApp().run()
